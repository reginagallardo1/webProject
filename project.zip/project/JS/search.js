$(document).ready(function(){

//CHECK SESSION

		$.ajax({

		                url : "php/checksession.php",
		                type: 'get',
		                contentType : "application/x-www-form-urlencoded",
		                success: function(jsonResponse){
		                },
		                error : function(errorMessage){
		                    alert("please log in");
		                    window.location.replace("login.html");
		                }

		            });

		$("#doSearch").on("click", function(){

			var $word = $("#searchbox");
			$("#users").empty();
	

			if ($word.val() != ""){
				var jsonToSend = {
		                    "word" : $("#searchbox").val()
		                };

		        $.ajax({
		                    url : "php/search.php",
		                    type : "POST",
		                    data : jsonToSend,
		                    dataType : "json",
		                    contentType : "application/x-www-form-urlencoded",
		                    success: function(jsonResp){
		                    	var newHtml = "";
				                idPost = jsonResp.length;
				                for(i = 0; i < jsonResp.length; i++){

				                   newHtml += "<div>" + jsonResp[i].username + ": " + jsonResp[i].description  + "</br> "; 
				                   newHtml += "<input name= '" + jsonResp[i].username + "' class='view' type='Submit' value='view profile'></div> ";

				                }
				                $("#users").append(newHtml);
		                    },
		                    error : function(errorMessage){
		                        var newHtml = "";
		                        newHtml += "<div> NO RESULTS WERE FOUND </div> ";
		                        $("#users").append(newHtml);
		                    }

		                });


			}
			
		});

		$('#users').delegate(".view", "click", function(){


			var jsonToSend = {
		                    "username" : $(this).attr('name'),
		                };

		                $.ajax({
		                    url : "php/view.php",
		                    type : "POST",
		                    data : jsonToSend,
		                    dataType : "json",
		                    contentType : "application/x-www-form-urlencoded",
		                    success: function(jsonResponse){
		                    	window.location.replace("view.html");

		                    },
		                    error : function(errorMessage){
		                        alert(errorMessage.responseText);
		                    }

		                });


		});



});