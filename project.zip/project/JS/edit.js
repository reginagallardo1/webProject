$(document).ready(function(){

// CHECK SESSION

			$.ajax({

		                url : "php/checksession.php",
		                contentType : "application/x-www-form-urlencoded",
		                success: function(jsonResponse){
		                },
		                error : function(errorMessage){
		                	alert("please log in");
                            window.location.replace("login.html");

		                }

		            });

//COMPLETE SELECT BOXES

				var newHtml = "";

                for(i = 2000; i > 1910; i--){

                   newHtml += "<option name='year' value='" + i + "'> " + i + "</option> "; 
                }
                $("#year").append(newHtml);

                $.ajax({
                url: "data/countries.json",
                type: "GET",
                dataType: "json",
                success: function(jsonData){
                    newHtml = "";

                    for (var i = 0; i < jsonData.length; i ++){
                        newHtml += "<option name='country' value='" + jsonData[i].name + "'>" + jsonData[i].name + "</option>";
                    }

                    $("#country").append(newHtml);

                }
            });

// CHECK IF ALL DATA IS ENTERED

	$("#save").on("click", function(){

		var $firstName = $("#firstName");
		var $lastName = $("#lastName");
		var $description = $("#description");

		var $full = true;

		if ($firstName.val() == ""){
			$("#checkFirstName").text("Please provide your first name");
			$full = false;
		}
		else{
			$("#checkFirstName").text("");
		}

		if ($lastName.val() == ""){
			$("#checkLastName").text("Please provide your last name");
			$full = false;
		}
		else{
			$("#checkLastName").text("");
		}


		if ($description.val() == ""){
			$("#checkDescription").text("Please enter your description");
			$full = false;
		}
		else{
			$("#checkDescription").text("");
		}

//IF DATA COMPLETE, REGISTER

		if($full){
			var jsonToSend = {
		                    "firstName" : $("#firstName").val(),
		                    "lastName" : $("#lastName").val(),
		                    "description" : $("#description").val(),
		                    "year" : $("[name=year]:selected").val(),
		                    "country" : $("[name=country]:selected").val(),
		                    "gender" : $("[name=gender]:checked").val(),
		                    "preference" : $("[name=preference]:checked").val()
		                };

		                $.ajax({
		                    url : "php/edit.php",
		                    type : "POST",
		                    data : jsonToSend,
		                    dataType : "json",
		                    contentType : "application/x-www-form-urlencoded",
		                    success: function(jsonResponse){
		                        alert("changes saved");
		                        window.location.replace("profile.html");
		                    },
		                    error : function(errorMessage){
		                        alert(errorMessage.responseText);
		                    }

		                });
		}

	});

});

