

$(document).ready(function(){
	$("#home").on("click", function(){
			window.location.href = "home.html";
	});

	$("#profile").on("click", function(){
			window.location.href = "profile.html";
	});

	$("#interests").on("click", function(){
			window.location.href = "interests.html";
	});

	$("#search").on("click", function(){
			window.location.href = "search.html";
	});

	$("#logout").on("click", function(){

			$.ajax({

		                url : "php/logout.php",
		                contentType : "application/x-www-form-urlencoded",
		                success: function(jsonResponse){
		                    window.location.replace("login.html");
		                },
		                error : function(errorMessage){
		                    alert(errorMessage.responseText);
		                }

		            });
			
	});

});