$(document).ready(function(){

// CHECK SESSION

			$.ajax({

		                url : "php/checksession.php",
		                contentType : "application/x-www-form-urlencoded",
		                success: function(jsonResponse){
		                	 window.location.replace("home.html");
		                },
		                error : function(errorMessage){

		                }

		            });

//COMPLETE SELECT BOXES

				var newHtml = "";

                for(i = 2000; i > 1910; i--){

                   newHtml += "<option name='year' value='" + i + "'> " + i + "</option> "; 
                }
                $("#year").append(newHtml);

                $.ajax({
                url: "data/countries.json",
                type: "GET",
                dataType: "json",
                success: function(jsonData){
                    newHtml = "";

                    for (var i = 0; i < jsonData.length; i ++){
                        newHtml += "<option name='country' value='" + jsonData[i].name + "'>" + jsonData[i].name + "</option>";
                    }

                    $("#country").append(newHtml);

                }
            });

// CHECK IF ALL DATA IS ENTERED

	$("#register").on("click", function(){

		var $firstName = $("#firstName");
		var $lastName = $("#lastName");
		var $username = $("#username");
		var $password = $("#password");
		var $passwordConfirmation = $("#passwordConfirmation");
		var $description = $("#description");
		var $profilePicture = $("#profilePicture");

		var $full = true;

		if ($firstName.val() == ""){
			$("#checkFirstName").text("Please provide your first name");
			$full = false;
		}
		else{
			$("#checkFirstName").text("");
		}

		if ($profilePicture.val() == ""){
			$("#checkProfilePicture").text("Please provide a profile picture");
			$full = false;
		}
		else{
			$("#checkFirstName").text("");
		}

		if ($lastName.val() == ""){
			$("#checkLastName").text("Please provide your last name");
			$full = false;
		}
		else{
			$("#checkLastName").text("");
		}

		if ($username.val() == ""){
			$("#checkUsername").text("Please provide your username");
			$full = false;
		}
		else{
			$("#checkUsername").text("");
		}

		if ($password.val() == ""){
			$("#checkPassword").text("Please provide your password");
			$full = false;
		}
		else{
			$("#checkPassword").text("");
		}

		if ($passwordConfirmation.val() == ""){
			$("#checkPasswordConfirmation").text("Please confirm your password");
			$full = false;
		}
		else{
			$("#checkPasswordConfirmation").text("");
		}

		if ($passwordConfirmation.val() != "" && $password.val() != "" && $password.val() != $passwordConfirmation.val()){
			$("#checkPasswordConfirmation").text("your passwords do not match");
			$full = false;
		}

		if ($description.val() == ""){
			$("#checkDescription").text("Please enter your description");
			$full = false;
		}
		else{
			$("#checkDescription").text("");
		}

//IF DATA COMPLETE, REGISTER

		if($full){
			var jsonToSend = {
		                    "firstName" : $("#firstName").val(),
		                    "lastName" : $("#lastName").val(),
		                    "username" : $("#username").val(),
		                    "password" : $("#password").val(),
		                    "description" : $("#description").val(),
		                    "year" : $("[name=year]:selected").val(),
		                    "country" : $("[name=country]:selected").val(),
		                    "gender" : $("[name=gender]:checked").val(),
		                    "preference" : $("[name=preference]:checked").val(),
		                };

		                $.ajax({
		                    url : "php/register.php",
		                    type : "POST",
		                    data : jsonToSend,
		                    dataType : "json",
		                    contentType : "application/x-www-form-urlencoded",
		                    success: function(jsonResponse){
		                        alert("Registration succesfull");
		                        window.location.replace("home.html");
		                    },
		                    error : function(errorMessage){
		                        alert(errorMessage.responseText);
		                    }

		                });
		}

	});

});

