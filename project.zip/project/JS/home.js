$(document).ready(function(){

//CHECK SESSION
	var username = "";

		$.ajax({

		                url : "php/checksession.php",
		                type: 'get',
		                contentType : "application/x-www-form-urlencoded",
		                success: function(jsonResponse){
		                	username = jsonResponse;
		                	$("#welcome").append(username);
		
		                },
		                error : function(errorMessage){
		                    alert("please log in");
		                    window.location.replace("login.html");
		                }

		            });

// POST USERS

		$.ajax ({
            url : "php/users.php",
            type : "POST",
            dataType : "json",
            contentType : "application/x-www-form-urlencoded",
            success : function(jsonResp){
                var newHtml = "";
                idPost = jsonResp.length;
                for(i = 0; i < jsonResp.length; i++){

                   newHtml += "<div>" + jsonResp[i].username + ": " + jsonResp[i].description  + "</br> "; 
                   newHtml += "<input name= '" + jsonResp[i].username + "' class='view' type='Submit' value='view profile'></div> ";

                }

       
                $("#users").append(newHtml);

            },
            error: function(errorMsg){
                console.log(errorMsg.statusText);
            }
        });

// VIEW OTHER USER PROFILE

		$('#users').delegate(".view", "click", function(){


			var jsonToSend = {
		                    "username" : $(this).attr('name'),
		                };

		                $.ajax({
		                    url : "php/view.php",
		                    type : "POST",
		                    data : jsonToSend,
		                    dataType : "json",
		                    contentType : "application/x-www-form-urlencoded",
		                    success: function(jsonResponse){
		                    	window.location.replace("view.html");

		                    },
		                    error : function(errorMessage){
		                        alert(errorMessage.responseText);
		                    }

		                });


		});


});