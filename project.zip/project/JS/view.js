$(document).ready(function(){

            $.ajax({

                        url : "php/checksession.php",
                        contentType : "application/x-www-form-urlencoded",
                        success: function(jsonResponse){
                        },
                        error : function(errorMessage){
                            alert("please log in");
                            window.location.replace("login.html");
                        }

                    });

        $.ajax ({
            url : "php/viewProfile.php",
            type : "POST",
            dataType : "json",
            contentType : "application/x-www-form-urlencoded",
            success : function(jsonResp){
                var newHtml = "";
                var newHtmlButton = "";
                //for(var element in jsonResp){
                    newHtml += "<div id='profileInfo'>";
                    newHtml += "<p>Username: <span id='username'>" + jsonResp.username + "</span></p>";
                    newHtml += "<p>First name: <span id='fname'>" + jsonResp.fName + "</span></p>";
                    newHtml += "<p>Last name: <span id='lname'>" + jsonResp.lName + "</span></p>";
                    newHtml += "<p>Year of birth: <span id='year'>" + jsonResp.year + "</span></p>";
                    newHtml += "<p>Country: <span id='country'>" + jsonResp.country + "</span></p>";
                    newHtml += "<p>Gender: <span id='gender'>" + jsonResp.gender + "</span></p>";
                    newHtml += "<p>Sexual Preference: <span id='preference'>" + jsonResp.preference + "</span></p>";
                    newHtml += "<p>description: <span id='description'>" + jsonResp.description + "</span></p>";
                    newHtml += "</div>";
                    newHtmlButton += "<input name= '" + jsonResp.username + "' id='add' type='Submit' value='Im interested'> ";

                //}
                $("#profileInfo").replaceWith(newHtml);
                $("#interested").append(newHtmlButton);
                newHtml = "<img id='profilePicture' src='" + jsonResp.picture + "''>";
                 $("#profilePicture").replaceWith(newHtml);
            },
            error: function(errorMsg){
                console.log(errorMsg.message);
            }
        });

        $.ajax ({
            url : "php/messages.php",
            type : "POST",
            dataType : "json",
            contentType : "application/x-www-form-urlencoded",
            success : function(jsonResp){
                var newHtml = "";
                idPost = jsonResp.length;
                for(i = 0; i < jsonResp.length; i++){

                   newHtml += "<div>" + jsonResp[i].username + ": " + jsonResp[i].comment  + "</br> "; 
                   newHtml += "</div>";

                }
                $("#comments").append(newHtml);
            },
            error: function(errorMsg){
                console.log(errorMsg.statusText);
            }
        });

        $("#send").on("click",function(){
            var $message = $("#newMessage");
            if ($message.val() != ""){

                var jsonToSend = {
                        "message" : $("#newMessage").val(),
                    };

                 $.ajax ({
                    url : "php/newMessage.php",
                    type : "POST",
                    data : jsonToSend,
                    dataType : "json",
                    contentType : "application/x-www-form-urlencoded",
                    success : function(jsonResp){
                        window.location.replace("view.html");
                    },
                    error: function(errorMsg){
                        console.log(errorMsg.statusText);
                    }
                });
                
            }
             $message.val("");

        });

        $('#interested').delegate("#add", "click", function(){


                        $.ajax({
                            url : "php/add.php",
                            contentType : "application/x-www-form-urlencoded",
                            success: function(jsonResponse){
                                alert("contact added to your list");

                            },
                            error : function(errorMessage){
                                alert(errorMessage.responseText);
                            }

                        });


        });


});