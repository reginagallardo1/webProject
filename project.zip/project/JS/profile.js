$(document).ready(function(){

            $.ajax({

                        url : "php/checksession.php",
                        contentType : "application/x-www-form-urlencoded",
                        success: function(jsonResponse){
                        },
                        error : function(errorMessage){
                            alert("please log in");
                            window.location.replace("login.html");
                        }

                    });

        $.ajax ({
            url : "php/profile.php",
            type : "POST",
            dataType : "json",
            contentType : "application/x-www-form-urlencoded",
            success : function(jsonResp){
                var newHtml = "";
                //for(var element in jsonResp){
                    newHtml += "<div id='profileInfo'>";
                    newHtml += "<p>Username: <span id='username'>" + jsonResp.username + "</span></p>";
                    newHtml += "<p>First name: <span id='fname'>" + jsonResp.fName + "</span></p>";
                    newHtml += "<p>Last name: <span id='lname'>" + jsonResp.lName + "</span></p>";
                    newHtml += "<p>Year of birth: <span id='year'>" + jsonResp.year + "</span></p>";
                    newHtml += "<p>Country: <span id='country'>" + jsonResp.country + "</span></p>";
                    newHtml += "<p>Gender: <span id='gender'>" + jsonResp.gender + "</span></p>";
                    newHtml += "<p>Sexual Preference: <span id='preference'>" + jsonResp.preference + "</span></p>";
                    newHtml += "<p>description: <span id='description'>" + jsonResp.description + "</span></p>";
                    newHtml += "</div>";

                //}
                $("#profileInfo").replaceWith(newHtml);

                newHtml = "<img id='profilePicture' src='" + jsonResp.picture + "''>";
                 $("#profilePicture").replaceWith(newHtml);
            },
            error: function(errorMsg){
                console.log(errorMsg.message);
            }
        });

        $.ajax ({
            url : "php/comments.php",
            type : "POST",
            dataType : "json",
            contentType : "application/x-www-form-urlencoded",
            success : function(jsonResp){
                var newHtml = "";
                idPost = jsonResp.length;
                for(i = 0; i < jsonResp.length; i++){

                   newHtml += "<div>" + jsonResp[i].username + ": " + jsonResp[i].comment  + "</br> "; 
                   newHtml += "<input id ='" + jsonResp[i].idComment + "' name= '" + jsonResp[i].username + "' class='reply' type='Submit' value='reply'> ";
                   newHtml += "<input name= '" + jsonResp[i].idComment + "' class='ignore' type='Submit' value='ignore'></div> ";

                }
                $("#comments").append(newHtml);
            },
            error: function(errorMsg){
                console.log(errorMsg.statusText);
            }
        });

        $('#comments').delegate(".reply", "click", function(){


            var jsonToSend = {
                            "username" : $(this).attr('name'),
                            "idComment" : $(this).attr('id')

                        };

                        $.ajax({
                            url : "php/view.php",
                            type : "POST",
                            data : jsonToSend,
                            dataType : "json",
                            contentType : "application/x-www-form-urlencoded",
                            success: function(jsonResponse){
                                window.location.replace("view.html");

                            },
                            error : function(errorMessage){
                                alert(errorMessage.responseText);
                            }

                        });


        });

        $('#comments').delegate(".ignore", "click", function(){

            var jsonToSend = {
                            "idComment" : $(this).attr('name'),
                        };

                        $.ajax({
                            url : "php/hideComment.php",
                            type : "POST",
                            data : jsonToSend,
                            dataType : "json",
                            contentType : "application/x-www-form-urlencoded",
                            success: function(jsonResponse){
                                window.location.replace("profile.html");

                            },
                            error : function(errorMessage){
                                alert(errorMessage.responseText);
                            }

                        });


        });

        $("#edit").on("click", function(){
            window.location.href = "edit.html";
    });
});