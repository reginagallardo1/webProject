<?php
	header('Content-type: application/json');

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "ReginaGallardo11";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	// Check connection
	if ($conn->connect_error) 
	{
	    header('HTTP/1.1 500 Bad connection to Database');
	    die("The server is down, we couldn't establish the DB connection");
	}
	else
	{

		$username = $_POST['username'];
		
		$sql = "SELECT username FROM Users WHERE username = '$username'";
		$result = $conn->query($sql);

		if($result->num_rows > 0)
		{
			header('HTTP/1.1 409 Conflict, Username already in use');
			die('Username already in use');
		}
		else
		{
			
			$password = $_POST['password'];
			$firstName = $_POST['firstName'];
			$lastName = $_POST['lastName'];
			$year = $_POST['year'];
			$country = $_POST['country'];
			$gender = $_POST['gender'];
			$preference = $_POST['preference'];
			$description = $_POST['description'];

			$picture = $_POST['picture'];

			$hash = md5($password);



			
			$sql = "INSERT INTO Users (fName, lName, username, passwrd, year, country, gender, preference, description) VALUES ('$firstName', '$lastName', '$username', '$hash', '$year', '$country', '$gender', '$preference', '$description')";
	    	
	    	if (mysqli_query($conn, $sql)) 
	    	{
	    		session_start();
				$_SESSION["username"] = $username;
			    echo json_encode("New record created successfully");
			} 
			else 
			{
				header('HTTP/1.1 500 Bad connection, something went wrong while saving your data, please try again later');
			    die("Error: " . $sql . "\n" . mysqli_error($conn));
			}
			
		}
	}


	$conn->close();
?>