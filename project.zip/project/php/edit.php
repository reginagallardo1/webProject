<?php
	header('Content-type: application/json');

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "ReginaGallardo11";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	// Check connection
	if ($conn->connect_error) 
	{
	    header('HTTP/1.1 500 Bad connection to Database');
	    die("The server is down, we couldn't establish the DB connection");
	}
	else
	{

			session_start();
			$username = $_SESSION["username"];
			$firstName = $_POST['firstName'];
			$lastName = $_POST['lastName'];
			$year = $_POST['year'];
			$country = $_POST['country'];
			$gender = $_POST['gender'];
			$preference = $_POST['preference'];
			$description = $_POST['description'];
			
			$sql = "UPDATE Users SET fName ='$firstName', lName ='$lastName', year ='$year', country ='$country', gender ='$gender', preference ='$preference', description = '$description' WHERE username ='$username'";

			
	    	
	    	if (mysqli_query($conn, $sql)) 
	    	{
			    echo json_encode("record updated succesfully");
			} 
			else 
			{
				header('HTTP/1.1 500 Bad connection, something went wrong while saving your data, please try again later');
			    die("Error: " . $sql . "\n" . mysqli_error($conn));
			}
			
	}


	$conn->close();
?>