

CREATE TABLE Users (
    fName VARCHAR(30) NOT NULL,
    lName VARCHAR(30) NOT NULL,
    username VARCHAR(50) NOT NULL PRIMARY KEY,
    passwrd VARCHAR(50) NOT NULL,
    year VARCHAR(4) NOT NULL,
    country VARCHAR(30) NOT NULL,
    gender VARCHAR(5) NOT NULL,
    preference VARCHAR(5) NOT NULL,
    picture VARCHAR(100),
    description VARCHAR(300) NOT NULL
    
);

CREATE TABLE Comments (
    username VARCHAR(50) NOT NULL,
    comment VARCHAR(200) NOT NULL,
    idComment VARCHAR(200) NOT NULL,
    reciever VARCHAR(50) NOT NULL,
    primary key (idComment)
    
);

CREATE TABLE Interested (
    username VARCHAR(50) NOT NULL,
    picture VARCHAR(50) NOT NULL,
    primary key (username, picture)
    
);

INSERT INTO Users(fName, lName, username, year, country, gender, preference, passwrd, picture, description)
VALUES              ('Regina', 'Gallardo', 'reginagallardo1', '1995','Mexico', 'f', 'm', 'password', '', 'my name is regina');


INSERT INTO Comments(username, comment, idComment, reciever)
VALUES              ('reginagallardo1', 'you suck', '0', 'pablogallardo1');

INSERT INTO Comments(username, comment, idComment, reciever)
VALUES              ('carlosgallardo1', 'ponte a estudiar', '0', 'reginagallardo1');

INSERT INTO Comments(username, comment, idComment, reciever)
VALUES              ('blancamariscal', 'hurry up', '0', 'reginagallardo1');

