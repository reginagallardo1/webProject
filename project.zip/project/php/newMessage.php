<?php
	header('Content-type: application/json');

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "ReginaGallardo11";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	// Check connection
	if ($conn->connect_error) 
	{
	    header('HTTP/1.1 500 Bad connection to Database');
	    die("The server is down, we couldn't establish the DB connection");
	}
	else
	{
			session_start();


			$username = $_SESSION["username"];
			$message = $_POST['message'];
			$reciever = $_SESSION["view"];
			$idComment = uniqid();
	
			$sql = "INSERT INTO Comments (username, comment, idComment, reciever, view) VALUES ('$username', '$message', '$idComment', '$reciever', 1)";
	    	
	    	if (mysqli_query($conn, $sql)) 
	    	{
			    echo json_encode("posted successfully");

			} 
			else 
			{				
				header('HTTP/1.1 500 Bad connection, something went wrong while saving your data, please try again later');
			    die("Error: " . $sql . "\n" . mysqli_error($conn));
			}
			
	}


	$conn->close();
?>