<?php
	header('Content-type: application/json');

	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "ReginaGallardo11";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	// Check connection
	if ($conn->connect_error) 
	{
	    header('HTTP/1.1 500 Bad connection to Database');
	    die("The server is down, we couldn't establish the DB connection");
	}
	else
	{
		session_start();

		$username = $_SESSION['username'];
		$user =  $_POST['user'];
			
			$sql = "DELETE FROM Interested WHERE username = '$username' AND user = '$user'";
	    	
	    	if (mysqli_query($conn, $sql)) 
	    	{
			    echo json_encode("contact remove");
			} 
			else 
			{
				header('HTTP/1.1 500 Bad connection, something went wrong while saving your data, please try again later');
			    die("Error: " . $sql . "\n" . mysqli_error($conn));
			}
			
		
	}


	$conn->close();
?>